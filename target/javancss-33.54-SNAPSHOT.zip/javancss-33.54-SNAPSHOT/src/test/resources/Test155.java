public class NewInnerClass
{

    public Example()
    {
        Example.Test test = this.new Test();
    }

    private class Test
    {

    }
}
