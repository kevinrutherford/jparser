public class Jacob2 {
    public synchronized void createMakefile() {
        sMakefile = Util.replace(sMakefile, "\\", Init.S_FILE_SEPARATOR);
    }

    public void test() {

    }
}
