public enum AnEnum {
  A, B, C, D;
  /**
   * test
   */
  public int aMethod() {
    return ordinal() * 100;
  }
}
