import java.io.InputStream;

public class Test51 {
    public Test51() {
        super();
    }

    public Test51( int i ) {
        super( i );
    }

    public Test51( Object o ) {
        super((InputStream)null, null);
    }
}
