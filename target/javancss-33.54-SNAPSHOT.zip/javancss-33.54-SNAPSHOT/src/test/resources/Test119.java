public interface test {
    public enum sub{ ONE };
}
