import java.util.Map;
import java.util.Set;

public class Test132
{
  public Set<String>[] conditions;
  public Map<String, String> conditions2;
  public Set<String> conditions3;
  public Set<String>[] conditions4;
  public Set<String[]> conditions5;
  public Set<Set<String[]>> conditions6;
  public Set<Set<String>[]> conditions7;
  public Map<String, Set<String>[]> conditions8;

  public Test132()
  {
  }
}
