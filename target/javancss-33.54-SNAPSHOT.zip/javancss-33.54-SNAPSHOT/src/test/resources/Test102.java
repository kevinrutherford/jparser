public class AClass {
  private int n;
  private String s;
  public AClass(int n, String s) {
    this.n = n;
    this.s = s;
  }
  public int getN() {
    return n;
  }
  public String getS() {
    return s;
  }
}
