public class Test55
{
    public Test55( Hashtable prefs )
    {
    this( "test" );
    }

    public Test56( String name )
    {
    super();
    }
}
