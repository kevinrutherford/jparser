public class Test74
{
  static public interface StaticInnerInterface
  {
  }
}
